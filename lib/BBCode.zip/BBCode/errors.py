class MarkupSyntaxError(ValueError):
    pass
